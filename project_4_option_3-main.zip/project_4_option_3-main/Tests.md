# FORMAT TO DOCUMENT TESTS

Test 1: User log in
Steps:

1. User launches application.
2. User selects the username textbox.
3. User enters username via the keyboard.
4. User selects the password textbox.
5. User selects the "Log in" button. 

Expected result: Application verifies the user's username and password and loads their homepage automatically. 

Test Status: Passed. 
